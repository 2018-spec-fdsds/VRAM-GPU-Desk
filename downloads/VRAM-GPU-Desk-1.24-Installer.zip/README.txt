VRAM GPU Desk 1.24 - Windows x64

Run VRAM-GPU-Desk-1.24-Setup-x64.exe. Windows administrator approval is required to install the protected control and licensing tasks. The installer can close the existing application before updating. User settings are retained.

NVIDIA VRAM monitoring and configurable force-close actions; temperature and idle-cooling control, optional overheating emergency mode, CPU/RAM indicators, transparent GPU overlays, compatible digital PSU telemetry. Second NVIDIA GPU control is experimental.

Activation: 60 days from the first launch of the activation-enabled application on this computer. Ordinary updates and uninstall retain the protected date. Afterwards all features remain available; a localized nonmodal topmost reminder appears at least hourly. Activation controls then generate/save a 20-character request and accept a 20-character offline device-bound response. Valid activation stops reminders. Hardware identity changes invalidate activation without resetting the period. No automatic HWID upload. The owner's private issuer/master is excluded. Compact offline verification is not resistant to determined binary analysis.

Source code and private activation tools are not included.
Project: https://github.com/2018-spec-fdsds/VRAM-GPU-Desk
License: see LICENSE.md.

Corrected 1.24 build: resolve protected activation state through the Windows machine known-folder API in the clean native host environment. Fail closed on unresolved/relative paths. During update, remove only the exact empty protected legacy reservation from the first 1.24 build; never remove state, contents or linked paths.

Corrected activation persistence: repeated status reads and restarts use a dedicated strict JSON state codec with boolean activation and nullable recovery date, retaining the original protected first-launch anchor.

Protected-state file security is now assigned atomically at creation. A legacy empty inherited admin/System-only lock is protected without changing state contents. Full production Lock/Save/Load/restart/expiry/activation was verified in an isolated elevated synthetic fixture.
